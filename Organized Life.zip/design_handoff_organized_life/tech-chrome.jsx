// Shared techy chrome layer — wraps both directions with HUD/terminal flourishes.
// Designed to overlay without disturbing the underlying layout.

const TC = {
  // Animated ticker text — financial / system stats
  TICKER_ITEMS: [
    "SYS·ONLINE",
    "UPTIME 14d 03h 22m",
    "VTI +0.42%",
    "BTC $94,218 ↑1.8%",
    "HRV 64ms",
    "SLEEP 7h 12m · 86%",
    "FOCUS 3h 18m · DEEP",
    "QUEUE 4 P1 · 2 P2",
    "CAL 5 EVENTS",
    "INBOX 3 UNREAD",
    "STRAVA 11.2mi/wk",
    "API 247ms",
    "PUSH ✓ main@a3f8c1",
    "BUILD #1247 PASS",
    "CACHE 94% HIT",
    "WAKE 06:42",
    "REM 1h 48m",
    "SOL ↑ 06:18",
    "SOL ↓ 19:43",
    "WIND 8mph NE",
  ],
};

// Inject ticker animation CSS once
if (typeof document !== 'undefined' && !document.getElementById('tc-styles')) {
  const s = document.createElement('style');
  s.id = 'tc-styles';
  s.textContent = `
    @keyframes tc-ticker { from { transform: translateX(0); } to { transform: translateX(-50%); } }
    @keyframes tc-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }
    @keyframes tc-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
    @keyframes tc-scan { 0% { transform: translateY(-100%); } 100% { transform: translateY(100%); } }
    .tc-ticker-track { display: inline-flex; gap: 32px; animation: tc-ticker 90s linear infinite; white-space: nowrap; }
    .tc-blink { animation: tc-blink 1s step-end infinite; }
    .tc-pulse { animation: tc-pulse 2s ease-in-out infinite; }
  `;
  document.head.appendChild(s);
}

// ── TopBar — system status strip with ticker ──────────
const TechTopBar = ({ accent, bg, text, textMuted, mono = '"JetBrains Mono", monospace', variant = "editorial" }) => {
  const items = [...TC.TICKER_ITEMS, ...TC.TICKER_ITEMS];
  const now = new Date();
  const time = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
  const lat = "40.7128°N";
  const lon = "74.0060°W";

  return (
    <div style={{ height: 22, background: bg, color: text, borderBottom: `1px solid ${textMuted}33`, display: "flex", alignItems: "center", fontFamily: mono, fontSize: 9, letterSpacing: "0.12em", flexShrink: 0, overflow: "hidden" }}>
      {/* Left cluster — system label + signal */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 10px", borderRight: `1px solid ${textMuted}33`, height: "100%" }}>
        <span style={{ display: "flex", gap: 2, alignItems: "flex-end" }}>
          {[3, 5, 7, 9].map((h, i) => (
            <span key={i} style={{ width: 2, height: h, background: accent, opacity: i === 3 ? 1 : 0.5 }} />
          ))}
        </span>
        <span style={{ color: accent }}>● ONLINE</span>
        <span style={{ color: textMuted }}>v0.4.2-beta</span>
      </div>

      {/* Center — ticker */}
      <div style={{ flex: 1, overflow: "hidden", position: "relative", height: "100%", display: "flex", alignItems: "center" }}>
        <div className="tc-ticker-track">
          {items.map((it, i) => (
            <span key={i} style={{ color: i % 4 === 0 ? accent : textMuted }}>▸ {it}</span>
          ))}
        </div>
      </div>

      {/* Right cluster — coords + time */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "0 10px", borderLeft: `1px solid ${textMuted}33`, height: "100%" }}>
        <span style={{ color: textMuted }}>{lat} {lon}</span>
        <span>{time}<span className="tc-blink">_</span></span>
      </div>
    </div>
  );
};

// ── Bottom status bar — like an IDE statusline ────────
const TechBottomBar = ({ accent, bg, text, textMuted, mono = '"JetBrains Mono", monospace', page = "morning" }) => {
  const segments = [
    { label: "PAGE", val: page.toUpperCase(), accent: true },
    { label: "BRANCH", val: "main" },
    { label: "SYNC", val: "↑ 14:32" },
    { label: "LAT", val: "247ms" },
  ];
  const right = [
    { label: "CPU", val: "12%" },
    { label: "MEM", val: "184MB" },
    { label: "BAT", val: "94%" },
    { label: "© ORGANIZED LIFE", val: "" },
  ];
  return (
    <div style={{ height: 22, background: bg, color: text, borderTop: `1px solid ${textMuted}33`, display: "flex", alignItems: "center", fontFamily: mono, fontSize: 9, letterSpacing: "0.12em", flexShrink: 0 }}>
      {segments.map((s, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, padding: "0 12px", height: "100%", borderRight: `1px solid ${textMuted}33` }}>
          <span style={{ color: textMuted }}>{s.label}</span>
          <span style={{ color: s.accent ? accent : text }}>{s.val}</span>
        </div>
      ))}
      <div style={{ flex: 1 }} />
      {right.map((s, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, padding: "0 12px", height: "100%", borderLeft: `1px solid ${textMuted}33` }}>
          {s.label && <span style={{ color: textMuted }}>{s.label}</span>}
          <span>{s.val || s.label}</span>
        </div>
      ))}
    </div>
  );
};

// ── Corner crosshair / fiducial markers ────────────────
const Fiducial = ({ position, color, size = 14 }) => {
  const styles = {
    tl: { top: 6, left: 6, borderTop: `1px solid ${color}`, borderLeft: `1px solid ${color}` },
    tr: { top: 6, right: 6, borderTop: `1px solid ${color}`, borderRight: `1px solid ${color}` },
    bl: { bottom: 6, left: 6, borderBottom: `1px solid ${color}`, borderLeft: `1px solid ${color}` },
    br: { bottom: 6, right: 6, borderBottom: `1px solid ${color}`, borderRight: `1px solid ${color}` },
  };
  return <div style={{ position: "absolute", width: size, height: size, pointerEvents: "none", ...styles[position] }} />;
};

window.TC = TC;
window.TechTopBar = TechTopBar;
window.TechBottomBar = TechBottomBar;
window.Fiducial = Fiducial;
