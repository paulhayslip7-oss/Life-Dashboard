// Shared mock data + helpers for Organized Life prototypes.
// Realistic-feeling seed data so the dashboards look lived-in.

const todayKey = () => new Date().toISOString().slice(0, 10);
const dKey = (offset) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
};

const SEED_HABITS = [
  { id: 1, name: "Morning run", icon: "dumbbell", color: "rust", log: { [dKey(0)]: true, [dKey(-1)]: true, [dKey(-2)]: true, [dKey(-3)]: false, [dKey(-4)]: true, [dKey(-5)]: true, [dKey(-6)]: true } },
  { id: 2, name: "Read 30 min", icon: "list", color: "sage", log: { [dKey(0)]: true, [dKey(-1)]: true, [dKey(-2)]: false, [dKey(-3)]: true, [dKey(-4)]: true, [dKey(-5)]: true, [dKey(-6)]: false } },
  { id: 3, name: "No phone before 9am", icon: "moon", color: "indigo", log: { [dKey(0)]: false, [dKey(-1)]: true, [dKey(-2)]: true, [dKey(-3)]: true, [dKey(-4)]: false, [dKey(-5)]: true, [dKey(-6)]: true } },
  { id: 4, name: "Meditate", icon: "circle", color: "rust", log: { [dKey(0)]: true, [dKey(-1)]: true, [dKey(-2)]: true, [dKey(-3)]: true, [dKey(-4)]: true, [dKey(-5)]: false, [dKey(-6)]: true } },
  { id: 5, name: "Cold shower", icon: "thermo", color: "indigo", log: { [dKey(-1)]: true, [dKey(-2)]: true, [dKey(-3)]: true, [dKey(-4)]: true, [dKey(-5)]: true, [dKey(-6)]: true } },
  { id: 6, name: "Write 500 words", icon: "pen", color: "sage", log: { [dKey(0)]: false, [dKey(-1)]: true, [dKey(-2)]: false, [dKey(-3)]: true, [dKey(-4)]: false, [dKey(-5)]: true, [dKey(-6)]: false } },
];

const SEED_TODOS = [
  { id: 1, text: "Finish Q2 investor update deck", priority: "high", due: dKey(0), done: false, project: "Founders" },
  { id: 2, text: "Call dentist about cleaning", priority: "med", due: dKey(2), done: false, project: "Personal" },
  { id: 3, text: "Review Anya's PR on auth flow", priority: "high", due: dKey(0), done: false, project: "Engineering" },
  { id: 4, text: "Renew passport — 2 weeks out", priority: "high", due: dKey(7), done: false, project: "Personal" },
  { id: 5, text: "Buy birthday gift for Mom", priority: "med", due: dKey(4), done: false, project: "Personal" },
  { id: 6, text: "Cancel unused SaaS subscriptions", priority: "low", due: null, done: false, project: "Finance" },
  { id: 7, text: "Update LinkedIn with new role", priority: "low", due: null, done: false, project: "Career" },
  { id: 8, text: "Read Range by David Epstein", priority: "low", due: null, done: false, project: "Personal" },
  { id: 9, text: "Sign mortgage paperwork", priority: "high", due: dKey(-1), done: true, project: "Finance" },
  { id: 10, text: "Clean garage", priority: "med", due: null, done: true, project: "Home" },
  { id: 11, text: "Schedule annual physical", priority: "med", due: dKey(10), done: false, project: "Health" },
];

const SEED_GOALS = [
  { id: 1, title: "Run a sub-4 marathon", category: "Health", date: "2026-10-15", progress: 62, desc: "Chicago Marathon, October. Currently averaging 4:15 pace at threshold." },
  { id: 2, title: "Hit $250K in liquid savings", category: "Finance", date: "2026-12-31", progress: 78, desc: "Combination of HYSA + index funds. Currently at $194K." },
  { id: 3, title: "Ship Organized Life v1", category: "Business", date: "2026-08-01", progress: 41, desc: "Personal life-OS. Closed beta with 50 users by July." },
  { id: 4, title: "Read 24 books this year", category: "Personal", date: "2026-12-31", progress: 33, desc: "Aiming for two per month. 8 done so far." },
  { id: 5, title: "Bench 1.5x bodyweight", category: "Health", date: "2026-09-01", progress: 86, desc: "Currently 245 at 175lbs. 15 lbs to go." },
];

const SEED_WORKOUTS = [
  { id: 1, type: "Upper body — push", duration: 62, date: dKey(0), notes: "Bench 4x6 @ 210, OHP 4x8 @ 115, dips 3x12 BW+25" },
  { id: 2, type: "Easy run", duration: 45, date: dKey(-1), notes: "5.2 mi @ 8:30 pace. Felt good, low HR." },
  { id: 3, type: "Lower body", duration: 72, date: dKey(-2), notes: "Squat 5x5 @ 275, RDL 3x8 @ 225, lunges" },
  { id: 4, type: "Threshold run", duration: 50, date: dKey(-4), notes: "3x10 min @ 6:45 pace, 2 min jog" },
  { id: 5, type: "Upper body — pull", duration: 65, date: dKey(-5), notes: "Pull-ups 5x8 BW+25, rows 4x8 @ 185, curls" },
  { id: 6, type: "Long run", duration: 95, date: dKey(-7), notes: "11 mi @ 8:45. Perfect weather." },
];

const SEED_PRS = [
  { id: 1, exercise: "Back squat", value: 315, unit: "lbs", date: dKey(-21) },
  { id: 2, exercise: "Bench press", value: 245, unit: "lbs", date: dKey(-7) },
  { id: 3, exercise: "Deadlift", value: 405, unit: "lbs", date: dKey(-45) },
  { id: 4, exercise: "5K", value: "20:14", unit: "min:sec", date: dKey(-30) },
  { id: 5, exercise: "Mile", value: "5:48", unit: "min:sec", date: dKey(-60) },
];

const SEED_METRICS = { weight: 175, bf: 12.4, height: 71, hr: 52 };

const SEED_TX = [
  { id: 1, desc: "Salary — Acme Corp", amount: 8400, type: "income", category: "Salary", date: dKey(-2) },
  { id: 2, desc: "Rent", amount: 2850, type: "expense", category: "Housing", date: dKey(-2) },
  { id: 3, desc: "Whole Foods", amount: 142.18, type: "expense", category: "Food", date: dKey(-1) },
  { id: 4, desc: "Uber", amount: 24.50, type: "expense", category: "Transport", date: dKey(-1) },
  { id: 5, desc: "Freelance — design audit", amount: 1800, type: "income", category: "Freelance", date: dKey(-4) },
  { id: 6, desc: "Spotify", amount: 11.99, type: "expense", category: "Entertainment", date: dKey(-5) },
  { id: 7, desc: "Equinox", amount: 295, type: "expense", category: "Health", date: dKey(-6) },
  { id: 8, desc: "Trader Joe's", amount: 87.42, type: "expense", category: "Food", date: dKey(-7) },
  { id: 9, desc: "Dividend — VTI", amount: 312.40, type: "income", category: "Investment", date: dKey(-9) },
  { id: 10, desc: "Restaurant — Cosme", amount: 218, type: "expense", category: "Food", date: dKey(-10) },
];

const SEED_BUDGETS = [
  { name: "Housing", limit: 3000, spent: 2850 },
  { name: "Food", limit: 800, spent: 447.60 },
  { name: "Transport", limit: 200, spent: 124.50 },
  { name: "Entertainment", limit: 200, spent: 42.99 },
  { name: "Health", limit: 350, spent: 295 },
];

const SEED_ACCOUNTS = [
  { name: "Chase Checking", type: "Checking", balance: 14250 },
  { name: "Marcus HYSA", type: "Savings", balance: 62400 },
  { name: "Vanguard Brokerage", type: "Investment", balance: 131800 },
  { name: "Roth IRA", type: "Investment", balance: 48200 },
  { name: "Coinbase", type: "Crypto", balance: 8740 },
  { name: "Amex Platinum", type: "Debt", balance: -2418 },
];

const SEED_IDEAS = [
  { id: 1, title: "Organized Life", desc: "Personal life-OS. Single dashboard for habits, money, health, ideas. Currently building.", status: "progress" },
  { id: 2, title: "Trail-running coach app", desc: "Adaptive training plans for ultras. Pulls Strava, adjusts based on elevation + recovery.", status: "idea" },
  { id: 3, title: "Substack analytics tool", desc: "Show writers their best-performing topics, optimal send times, churn signals.", status: "idea" },
  { id: 4, title: "AI meal-planner for athletes", desc: "Macros + grocery list + prep order. Synced to training load.", status: "idea" },
  { id: 5, title: "Founder Sprint Club", desc: "Cohort program — 8 weeks, 8 founders, 1 launch each. Validated with 12 alumni.", status: "validated" },
];

const SEED_EVENTS = [
  { time: "8:00", title: "Morning run — 6 mi easy", sub: "Riverside path", color: "sage" },
  { time: "10:30", title: "Weekly 1:1 with Jordan", sub: "Zoom", color: "indigo" },
  { time: "12:30", title: "Lunch — Café Mogador", sub: "with Priya", color: "rust" },
  { time: "15:00", title: "Investor call — Sequoia", sub: "Series A check-in", color: "indigo" },
  { time: "18:30", title: "Dinner reservation", sub: "Cosme, 4 guests", color: "rust" },
];

const SEED_EMAILS = [
  { from: "Anya Petrov", subject: "PR #284 ready for review — auth refactor", time: "9:42a", unread: true },
  { from: "Sequoia Capital", subject: "Confirming our 3pm call today", time: "9:18a", unread: true },
  { from: "Stripe", subject: "Your weekly payout summary", time: "8:30a", unread: true },
  { from: "Mom", subject: "Re: Thanksgiving plans", time: "Yesterday", unread: false },
  { from: "Strava", subject: "You earned a new achievement", time: "Yesterday", unread: false },
  { from: "Notion", subject: "3 pages mentioned you this week", time: "Mon", unread: false },
];

const QUOTES = [
  { q: "Discipline is just choosing between what you want now and what you want most.", a: "Augusta F. Kantra" },
  { q: "What gets measured gets managed.", a: "Peter Drucker" },
  { q: "The best time to plant a tree was 20 years ago. The second best time is now.", a: "Chinese proverb" },
  { q: "Compound interest is the eighth wonder of the world.", a: "attributed to Einstein" },
  { q: "Action is the antidote to despair.", a: "Joan Baez" },
];

const SEED_NOW_PLAYING = {
  track: "Avril 14th",
  artist: "Aphex Twin",
  album: "Drukqs",
  progress: 0.42,
};

window.OL_DATA = {
  todayKey, dKey,
  SEED_HABITS, SEED_TODOS, SEED_GOALS, SEED_WORKOUTS, SEED_PRS, SEED_METRICS,
  SEED_TX, SEED_BUDGETS, SEED_ACCOUNTS, SEED_IDEAS, SEED_EVENTS, SEED_EMAILS,
  QUOTES, SEED_NOW_PLAYING,
};
