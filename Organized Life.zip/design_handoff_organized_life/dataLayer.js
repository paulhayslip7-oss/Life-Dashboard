// dataLayer.js — unified data layer for Organized Life
// Auto-detects Supabase config; falls back to localStorage seed data.
//
// To wire your real Supabase: paste URL + anon key below, then run the
// migration at supabase/migration.sql in your project's SQL editor.
//
// All read methods return Promises so the call shape is identical across
// the two backends. All mutations optimistically update the in-memory cache
// and notify subscribers, then sync to the backend.

(function () {
  // ─── Config ──────────────────────────────────────────
  const SUPABASE_URL = "https://ahagidiogknjukvwqwxp.supabase.co";
  const SUPABASE_ANON_KEY = "sb_publishable_kqeVrNhHzOdaizSVsa12CA_yt2oAZUZ";
  const LOCAL_KEY = "organized_life_v1";

  const D = window.OL_DATA;

  // ─── Mode detection ──────────────────────────────────
  const HAS_SUPABASE = !!(SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase);
  let sb = null;
  let userId = null;

  // ─── Local cache (the source of truth for the UI) ───
  // Shape mirrors what the UI expects.
  let cache = null;
  const subscribers = new Set();
  const notify = () => subscribers.forEach((fn) => fn(cache));

  // ─── Bootstrap from localStorage or seed ─────────────
  const seedFromMocks = () => ({
    tasks: D.SEED_TODOS.map(t => ({ ...t, id: String(t.id) })),
    habits: D.SEED_HABITS.map(h => ({ ...h, id: String(h.id) })),
    goals: D.SEED_GOALS.map(g => ({ ...g, id: String(g.id) })),
    workouts: D.SEED_WORKOUTS.map(w => ({ ...w, id: String(w.id) })),
    prs: D.SEED_PRS.map(p => ({ ...p, id: String(p.id) })),
    metrics: { ...D.SEED_METRICS },
    transactions: D.SEED_TX.map(x => ({ ...x, id: String(x.id) })),
    budgets: D.SEED_BUDGETS.map((b, i) => ({ ...b, id: String(i + 1) })),
    accounts: D.SEED_ACCOUNTS.map((a, i) => ({ ...a, id: String(i + 1) })),
    ideas: D.SEED_IDEAS.map(i => ({ ...i, id: String(i.id) })),
  });

  const loadLocal = () => {
    try {
      const raw = localStorage.getItem(LOCAL_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) { console.warn("local load failed", e); }
    const seeded = seedFromMocks();
    saveLocal(seeded);
    return seeded;
  };
  const saveLocal = (data) => {
    try { localStorage.setItem(LOCAL_KEY, JSON.stringify(data)); }
    catch (e) { console.warn("local save failed", e); }
  };

  // ─── Init ────────────────────────────────────────────
  const init = async () => {
    cache = loadLocal();
    notify();
    if (HAS_SUPABASE) {
      try {
        sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        const { data: { user } } = await sb.auth.getUser();
        if (user) {
          userId = user.id;
          await pullFromSupabase();
        } else {
          console.info("[dataLayer] No Supabase session — running on local cache. Sign in to sync.");
        }
      } catch (e) {
        console.warn("[dataLayer] Supabase init failed; using local cache.", e);
      }
    }
  };

  // ─── Supabase pull (full snapshot) ───────────────────
  const pullFromSupabase = async () => {
    if (!sb || !userId) return;
    const tables = [
      ["tasks", "tasks"],
      ["habits", "habits"],
      ["goals", "goals"],
      ["workouts", "workouts"],
      ["prs", "prs"],
      ["transactions", "transactions"],
      ["budgets", "budgets"],
      ["accounts", "accounts"],
      ["ideas", "ideas"],
    ];
    const next = { ...cache };
    for (const [key, tbl] of tables) {
      const { data, error } = await sb.from(tbl).select("*").eq("user_id", userId);
      if (!error && data) next[key] = data;
    }
    // habit_logs → fold into habits[].log
    const { data: logs } = await sb.from("habit_logs").select("*").eq("user_id", userId);
    if (logs) {
      next.habits = next.habits.map(h => ({
        ...h,
        log: logs.filter(l => l.habit_id === h.id).reduce((acc, l) => {
          acc[l.date] = l.done; return acc;
        }, {}),
      }));
    }
    const { data: m } = await sb.from("metrics").select("*").eq("user_id", userId).single();
    if (m) next.metrics = { weight: m.weight, bf: m.body_fat, height: m.height, hr: m.resting_hr };
    cache = next;
    saveLocal(cache);
    notify();
  };

  // ─── Mutation helpers ────────────────────────────────
  const update = (mutator) => {
    cache = mutator(cache);
    saveLocal(cache);
    notify();
  };

  const newId = () => "_" + Math.random().toString(36).slice(2, 11);

  // Try to mirror to Supabase, but never block the UI.
  const sync = async (table, op, payload) => {
    if (!sb || !userId) return;
    try {
      if (op === "insert") await sb.from(table).insert({ ...payload, user_id: userId });
      else if (op === "update") await sb.from(table).update(payload).eq("id", payload.id).eq("user_id", userId);
      else if (op === "delete") await sb.from(table).delete().eq("id", payload.id).eq("user_id", userId);
    } catch (e) { console.warn(`[dataLayer] ${table}.${op} sync failed`, e); }
  };

  // ─── Public API ──────────────────────────────────────
  const api = {
    init,
    subscribe(fn) { subscribers.add(fn); fn(cache); return () => subscribers.delete(fn); },
    get: () => cache,
    isCloud: () => !!(sb && userId),

    // ── Tasks ──
    addTask(task) {
      const row = { id: newId(), text: "", priority: "med", due: null, done: false, project: "Personal", ...task };
      update(c => ({ ...c, tasks: [row, ...c.tasks] }));
      sync("tasks", "insert", row);
      return row;
    },
    updateTask(id, patch) {
      update(c => ({ ...c, tasks: c.tasks.map(x => x.id === id ? { ...x, ...patch } : x) }));
      sync("tasks", "update", { id, ...patch });
    },
    toggleTask(id) {
      const t = cache.tasks.find(x => x.id === id);
      if (t) api.updateTask(id, { done: !t.done });
    },
    deleteTask(id) {
      update(c => ({ ...c, tasks: c.tasks.filter(x => x.id !== id) }));
      sync("tasks", "delete", { id });
    },

    // ── Habits ──
    addHabit(h) {
      const row = { id: newId(), name: "New habit", icon: "circle", color: "rust", log: {}, ...h };
      update(c => ({ ...c, habits: [...c.habits, row] }));
      sync("habits", "insert", { id: row.id, name: row.name, icon: row.icon, color: row.color });
      return row;
    },
    updateHabit(id, patch) {
      update(c => ({ ...c, habits: c.habits.map(x => x.id === id ? { ...x, ...patch } : x) }));
      const { log, ...rest } = patch;
      if (Object.keys(rest).length) sync("habits", "update", { id, ...rest });
    },
    deleteHabit(id) {
      update(c => ({ ...c, habits: c.habits.filter(x => x.id !== id) }));
      sync("habits", "delete", { id });
    },
    toggleHabitDay(habitId, dateKey) {
      const habit = cache.habits.find(h => h.id === habitId);
      if (!habit) return;
      const wasDone = !!habit.log[dateKey];
      const nowDone = !wasDone;
      update(c => ({
        ...c,
        habits: c.habits.map(h => h.id === habitId
          ? { ...h, log: { ...h.log, [dateKey]: nowDone } }
          : h),
      }));
      // habit_logs upsert
      if (sb && userId) {
        sb.from("habit_logs").upsert(
          { habit_id: habitId, user_id: userId, date: dateKey, done: nowDone },
          { onConflict: "habit_id,date" }
        ).then(() => {});
      }
    },

    // ── Goals ──
    addGoal(g) {
      const row = { id: newId(), title: "New goal", category: "Personal", date: "", progress: 0, desc: "", ...g };
      update(c => ({ ...c, goals: [...c.goals, row] }));
      sync("goals", "insert", { id: row.id, title: row.title, category: row.category, target_date: row.date || null, progress: row.progress, description: row.desc });
      return row;
    },
    updateGoal(id, patch) {
      update(c => ({ ...c, goals: c.goals.map(x => x.id === id ? { ...x, ...patch } : x) }));
      const dbPatch = { id };
      if ("title" in patch) dbPatch.title = patch.title;
      if ("category" in patch) dbPatch.category = patch.category;
      if ("date" in patch) dbPatch.target_date = patch.date || null;
      if ("progress" in patch) dbPatch.progress = patch.progress;
      if ("desc" in patch) dbPatch.description = patch.desc;
      sync("goals", "update", dbPatch);
    },
    deleteGoal(id) {
      update(c => ({ ...c, goals: c.goals.filter(x => x.id !== id) }));
      sync("goals", "delete", { id });
    },

    // ── Workouts ──
    addWorkout(w) {
      const row = { id: newId(), type: "Workout", duration: 60, date: D.todayKey(), notes: "", ...w };
      update(c => ({ ...c, workouts: [row, ...c.workouts] }));
      sync("workouts", "insert", row);
      return row;
    },
    deleteWorkout(id) {
      update(c => ({ ...c, workouts: c.workouts.filter(x => x.id !== id) }));
      sync("workouts", "delete", { id });
    },

    // ── PRs ──
    addPR(p) {
      const row = { id: newId(), exercise: "Lift", value: "0", unit: "lbs", date: D.todayKey(), ...p };
      update(c => ({ ...c, prs: [row, ...c.prs] }));
      sync("prs", "insert", row);
      return row;
    },
    deletePR(id) {
      update(c => ({ ...c, prs: c.prs.filter(x => x.id !== id) }));
      sync("prs", "delete", { id });
    },

    // ── Transactions ──
    addTransaction(x) {
      const row = { id: newId(), desc: "", amount: 0, type: "expense", category: "Other", date: D.todayKey(), ...x };
      update(c => ({ ...c, transactions: [row, ...c.transactions] }));
      sync("transactions", "insert", { id: row.id, description: row.desc, amount: row.amount, type: row.type, category: row.category, date: row.date });
      return row;
    },
    deleteTransaction(id) {
      update(c => ({ ...c, transactions: c.transactions.filter(x => x.id !== id) }));
      sync("transactions", "delete", { id });
    },

    // ── Ideas ──
    addIdea(i) {
      const row = { id: newId(), title: "New idea", desc: "", status: "idea", ...i };
      update(c => ({ ...c, ideas: [...c.ideas, row] }));
      sync("ideas", "insert", { id: row.id, title: row.title, description: row.desc, status: row.status });
      return row;
    },
    updateIdea(id, patch) {
      update(c => ({ ...c, ideas: c.ideas.map(x => x.id === id ? { ...x, ...patch } : x) }));
      const dbPatch = { id };
      if ("title" in patch) dbPatch.title = patch.title;
      if ("desc" in patch) dbPatch.description = patch.desc;
      if ("status" in patch) dbPatch.status = patch.status;
      sync("ideas", "update", dbPatch);
    },
    deleteIdea(id) {
      update(c => ({ ...c, ideas: c.ideas.filter(x => x.id !== id) }));
      sync("ideas", "delete", { id });
    },

    // ── Reset (dev) ──
    resetLocal() {
      localStorage.removeItem(LOCAL_KEY);
      cache = loadLocal();
      notify();
    },
  };

  window.OL_DATA_LAYER = api;
})();

// React hook for easy consumption
window.useDataLayer = function () {
  const [data, setData] = React.useState(window.OL_DATA_LAYER.get());
  React.useEffect(() => window.OL_DATA_LAYER.subscribe(setData), []);
  return [data, window.OL_DATA_LAYER];
};
