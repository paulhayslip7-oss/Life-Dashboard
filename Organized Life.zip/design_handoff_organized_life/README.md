# Handoff: Organized Life — Editorial Operator

## Overview
Organized Life is a personal life-OS dashboard — a single application that consolidates daily habits, tasks, goals, fitness, finance, and ideas. This handoff covers the **Editorial Operator** design direction: a broadsheet-newspaper aesthetic crossed with a Bloomberg-terminal HUD.

The product has 8 screens, all reachable from a persistent sidebar:
1. **Morning** — daily dashboard, hero greeting, telemetry strip, today's habits/tasks/agenda
2. **Tasks** — three-priority task manager (Urgent / Standard / Deferred)
3. **Habits** — week-grid habit ledger with streaks
4. **Goals** — long-view ambitions with progress bars
5. **Athletic** — body metrics, PRs, weekly volume, session log
6. **Finance** — net worth, transactions, budgets, holdings
7. **Build** (Ventures) — kanban-style idea stack (Ideas / In Progress / Validated)
8. **Wires** — connected services / integrations

## About the Design Files
The files in this bundle are **design references created in HTML** — interactive prototypes showing the intended look, layout, and behavior. They are **not production code to copy directly**.

Your task is to **recreate these designs in the target codebase's environment** (the existing repo this project came out of — Next.js / React with Supabase, based on context) using its established patterns and libraries.

The HTML prototypes:
- Use inline `<script type="text/babel">` and global `window.*` imports — this is a prototyping convenience, **not** the structure to ship.
- Use raw inline `style={{...}}` objects — replace with the codebase's styling solution (Tailwind, CSS modules, styled-components, etc.).
- Stub out interactions with shared component-level React state and a localStorage cache. The data layer (`dataLayer.js`) is closer to production-ready and shows the intended Supabase schema mapping.

## Fidelity
**High-fidelity.** Colors, typography, spacing, layout, and interactions are intentional and should be matched closely.

## Screens

### 1. Morning (`MorningPage` in `ed-pages.jsx`)

**Layout:** Single scrollable column, 28px top padding / 36px horizontal.
- **Masthead row** — 4px solid top border, 1px bottom border. 10px vertical padding. Three columns: date (left, uppercase mono 10px), "★ THE PERSONAL EDITION ★" (center, accent oxblood), weather/coords (right). Letter-spacing 0.18em.
- **Telemetry strip** — 6-column grid, no gaps between columns (1px right border between each). Each cell 8px/12px padding. Shows: SLEEP, HRV, FOCUS, STEPS, API, STREAK. Each cell: top row label (8px mono, muted) + status (8px mono, accent); bottom row big value (14px serif, weight 600) + 7-bar sparkline (last bar is accent color, others muted).
- **Hero block** — 28px top / 24px bottom padding. Kicker "FROM THE DESK OF [NAME]" in accent. Headline 76px Source Serif Pro 800-weight, tight line-height 0.95, -0.035em letter-spacing. Greeting on first line, italic accent-colored editorial tagline on second line. Sub-line italic, 16px, 720px max-width.
- **3-column body** with 1px vertical rules between (24px gaps):
  - **Left (1.4fr)**: Lead story (2-column flowed text, 14px, 1.55 line-height) + Dispatches (5 calendar events with mono time / serif title / italic muted location).
  - **Middle (1fr)**: Habits checklist (6 rows, 16px outlined squares with check icon when done) + Now Playing card (38px square album icon, italic track, muted artist).
  - **Right (1fr)**: Headline tasks (top 4 high-priority unchecked tasks with No. 01 / 02 / etc. mono numbering) + Editorial pull-quote box (paperAlt bg, 1px ink border, italic 16px) + Correspondence (3 emails: italic from-name, mono time, muted subject).

### 2. Tasks (`TodosPage`)
**Layout:** SectionHeader + 3-column priority grid (24px gaps) + Settled list at bottom.
- Each priority column: 2px-solid bottom-border header with kicker label "I · URGENT" / "II · STANDARD" / "III · DEFERRED" + count.
- Each task row: 14px outlined square checkbox (1.5px border, ink color), text 14px, mono 9px metadata line (project + due date) below.
- Settled section: separate group with `text-decoration: line-through`, accent2-colored check icons.
- "+ FILE NEW TASK" button top-right opens TaskModal.

### 3. Habits (`HabitsPage`)
**Layout:** SectionHeader + 4-stat row + week-grid table.
- Stat row: 4 cells, gridTemplateColumns "1.6fr 1fr 1fr 1fr", 1px right borders between, 2px bottom border. Each Stat: kicker label (9px mono uppercase), 44px serif number (700-weight, accent for first), italic muted sublabel.
- Week grid: gridTemplateColumns "180px 1fr repeat(7, 32px) 50px". Header row with kickers + weekday narrow letters (today's letter is accent). Each habit row: icon (accent) + name | streak progress bar (chip bg, accent fill) + "Nd" mono label | 7 daily cells (26×26, ink fill when done, accent border for today) | percentage right-aligned.

### 4. Goals (`GoalsPage`)
**Layout:** 2-column grid, 1px hairlines between cells.
- Each goal card (20×24px padding): kicker category (accent uppercase) + mono "BY YYYY-MM-DD" date right-aligned. Title 22px serif. Italic muted description. Progress: 8px chip-bg bar with accent fill + 1px top/bottom rules; large 28px serif number with smaller `%` muted.

### 5. Athletic (`AthleticPage`)
**Layout:** SectionHeader + 4-stat row + 2-column (PRs | Volume chart) + Session log.
- PRs list: 1px-dotted rows, 3-col grid (name | big-number value with mono unit | mono date).
- Volume chart: 12 vertical bars, 180px tall, ink color with last bar accent.
- Session log: rows with mono date | italic-serif type + notes | big duration number.

### 6. Finance (`FinancePage`)
**Layout:** SectionHeader + 4-stat row + 2-column (Transactions 1.3fr | Budget+Holdings 1fr).
- Transaction row: 4-col grid `80px 1fr 100px 110px` — mono date | desc + uppercase mono category | DR/CR mono | signed amount in serif.
- Budget bars: 6px chip-bg, ink fill (neg/red when >90%), label + "$spent / $limit" mono above.
- Holdings: account name + uppercase mono type | balance in serif (neg in red).

### 7. Build/Ventures (`BusinessPage`)
**Layout:** 3-column kanban with 1px hairline separators.
- Each column: header with kicker label + count | stacked idea cards (18px serif title, italic muted desc).

### 8. Wires (`IntegrationsPage`)
**Layout:** 2-column grid of service cards.
- Each card: 40×40 icon box | name + status pill (● ACTIVE / ○ DORMANT) + italic desc + Connect/Disconnect button.
- Footer status box showing backend mode + reset button.

## Persistent UI

### Sidebar (`Sidebar` in `ed-shell.jsx`)
180px wide, paperAlt bg, 1px right hairline.
- **Brand**: "Organized" / italic accent "Life" — 22px Source Serif Pro 700-weight, -0.02em letter-spacing.
- **Volume/Number stamp**: mono 9px uppercase ("Vol. III · No. 12").
- **Nav sections**: "TODAY", "WORK", "BODY", "MONEY", "BUILD", "SYSTEM" — mono 9px section labels.
- **Active state**: ink background with paper text, square corners (no border-radius).
- **Theme toggle bottom**: mono 10px uppercase, "Night Edition" / "Day Edition", 1px rule above.

### TechTopBar / TechBottomBar (`tech-chrome.jsx`)
Status bar chrome top and bottom with signal bars, version stamp, scrolling ticker, GPS coords, live ticking clock, IDE-style statusline (branch / sync time / latency / CPU/MEM/BAT). Decorative — keep ratio of content density even if you re-implement.

## Interactions & Behavior

| Action | Result |
|---|---|
| Click sidebar nav item | Navigate to that page |
| Click theme toggle | Toggle light ↔ dark |
| Click any task / habit / goal / workout / transaction / idea card | Open edit modal for that item |
| Click "+" button on page | Open new-entry modal |
| Click habit checkbox (Morning or Habits) | Toggle today's log; persists |
| Click task square checkbox | Toggle done state; persists |
| Click cell in habit week-grid | Toggle that day's log |
| Inside any modal: Save | Create or update; close modal |
| Inside any modal: Delete | Remove + close |
| Inside any modal: Cancel / click backdrop | Close without saving |

All mutations flow through `dataLayer` which optimistically updates local cache + notifies subscribers + best-effort syncs to Supabase.

## State Management

The prototype uses a single subscribable cache (`window.OL_DATA_LAYER`). In the target codebase, replace with:
- **React Query / SWR / TanStack Query** for server state (the schema in `supabase/migration.sql` is the contract)
- **Zustand / Jotai / context** for ephemeral UI state (which modal is open, which page is active, theme)

Schema reference: see `supabase/migration.sql`. Tables: `tasks`, `habits`, `habit_logs`, `goals`, `workouts`, `prs`, `metrics`, `transactions`, `budgets`, `accounts`, `ideas`. All user-scoped via RLS using `auth.uid()`.

## Design Tokens

### Colors

**Light theme** (`editorial-light`)
| Token | Hex | Use |
|---|---|---|
| paper | `#f4f1ea` | Page background |
| paperAlt | `#ebe6da` | Sidebar / muted card bg |
| ink | `#1a1814` | Primary text |
| inkSoft | `#5a544a` | Secondary text |
| inkMuted | `#8a8478` | Tertiary text |
| rule | `#1a1814` | Hard 1px–4px rules |
| ruleSoft | `rgba(26,24,20,0.18)` | Hairline / dotted rules |
| accent | `#a8331e` | Oxblood — kickers, accents, masthead star |
| accent2 | `#3a5239` | Forest — positive states |
| chip | `#dcd5c4` | Progress bar tracks |
| pos | `#3a5239` | Income / positive |
| neg | `#a8331e` | Over-budget / negative |

**Dark theme** (`editorial-dark`)
| Token | Hex |
|---|---|
| paper | `#15130f` |
| paperAlt | `#1d1a14` |
| ink | `#ebe5d6` |
| inkSoft | `#b9b1a0` |
| inkMuted | `#6a6354` |
| rule | `#ebe5d6` |
| ruleSoft | `rgba(235,229,214,0.18)` |
| accent | `#d96b52` |
| accent2 | `#7fa67d` |
| chip | `#2a261d` |

### Typography
- **Display / serif**: Source Serif 4 (aliased as "Source Serif Pro") — 400/600/700/800, normal + italic. Used for headlines, big numbers, body. Letter-spacing tightens at scale: -0.01em → -0.035em.
- **Mono**: JetBrains Mono — 400/500/600. All-caps with 0.1em–0.22em letter-spacing for kickers, labels, dates, ticker.
- **Sans (fallback / body small)**: system stack.

### Spacing scale
8px base. Common values: 4, 6, 8, 10, 12, 14, 18, 20, 24, 28, 36, 60.

### Border radii
**0px everywhere.** Squared corners are core to the editorial aesthetic — do not introduce border-radius.

### Borders / rules
- 1px solid (`rule` token) for hard separators
- 1px dotted `ruleSoft` for list rows
- 2px solid `rule` for section headers
- 4px solid `rule` for masthead top
- 3px-top + 1px-bottom DoubleRule for SectionHeader divider

### Shadows
None on the design surface. Modals get `0 30px 80px rgba(0,0,0,0.35)` only.

## Assets

- **Custom icon set** in `icons.jsx`: 24px monoline SVG, 1.5px stroke, currentColor. Names: sun, moon, link, check, checkSquare, plus, calendar, list, music, flame, target, dumbbell, wallet, rocket, trending, mail, pause, circle, pen, thermo. Re-export as a typed icon component in the target codebase, or substitute with Lucide / Heroicons (closest match: Lucide).
- **Fonts**: Google Fonts — Source Serif 4, Space Grotesk, JetBrains Mono. In Next.js, prefer `next/font/google`.
- No raster images / logos in the design. The brand is purely typographic.

## Files in this bundle

| File | Role |
|---|---|
| `Organized Life.html` | Entry — the live prototype |
| `ed-shell.jsx` | App shell + Sidebar + theme tokens + shared atoms (Kicker, SectionHeader, Stat, btnA, etc.) |
| `ed-pages.jsx` | All 8 page components |
| `modals.jsx` | 6 CRUD modals (Task, Habit, Goal, Workout, Transaction, Idea) |
| `icons.jsx` | Custom icon set |
| `data.jsx` | Seed data (used to bootstrap localStorage on first run) |
| `dataLayer.js` | Persistence layer — localStorage cache + Supabase sync |
| `tech-chrome.jsx` | TechTopBar + TechBottomBar + Fiducial corner markers |
| `design-canvas.jsx` | Pan/zoom artboard wrapper — **only for the prototype**, do not port |
| `supabase/migration.sql` | Schema with RLS policies — paste into Supabase SQL editor |

## Suggested implementation steps

1. **Apply the schema**: paste `supabase/migration.sql` into Supabase SQL editor.
2. **Set up the design tokens** in your codebase (Tailwind config / CSS vars / styled-system) using the table above.
3. **Add the icon set** — copy the SVG paths from `icons.jsx` into your icon component, or map to Lucide equivalents.
4. **Build the shell** — Sidebar + theme provider + page router.
5. **Port pages one at a time**, in this order: Morning → Tasks → Habits → Goals → Finance → Athletic → Build → Wires.
6. **Wire data fetching** with TanStack Query against the Supabase tables. The cache shape in `dataLayer.js` is your reference for what the UI expects.
7. **Add modals** matching `modals.jsx` — use whatever modal primitive your codebase already has (Radix Dialog, headlessui, etc.).
8. **Auth flow** — magic-link sign-in screen using `supabase.auth.signInWithOtp`. The prototype assumes a session already exists.

## Notes on what the prototype skips

- No sign-in UI yet (data layer is auth-aware but unused without a session).
- Workouts/transactions edit-modal is delete+add rather than true update — fix when porting.
- Budgets/Accounts on Finance page are read-only — no CRUD modal.
- Calendar events, emails, weather, now-playing, "From the desk of [name]" are static seed data — wire to real integrations (Google Calendar, Gmail, weather API, Spotify) in production.
