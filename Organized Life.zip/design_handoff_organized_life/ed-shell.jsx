// ed-shell.jsx — Editorial Operator app shell, sidebar, shared atoms.

const { useState: useStateS, useEffect: useEffectS } = React;
const D_S = window.OL_DATA;
const Icon_S = window.Icon;

const editorialTokens = {
  light: {
    paper: "#f4f1ea", paperAlt: "#ebe6da",
    ink: "#1a1814", inkSoft: "#5a544a", inkMuted: "#8a8478",
    rule: "#1a1814", ruleSoft: "rgba(26,24,20,0.18)",
    accent: "#a8331e", accent2: "#3a5239",
    chip: "#dcd5c4", pos: "#3a5239", neg: "#a8331e",
  },
  dark: {
    paper: "#15130f", paperAlt: "#1d1a14",
    ink: "#ebe5d6", inkSoft: "#b9b1a0", inkMuted: "#6a6354",
    rule: "#ebe5d6", ruleSoft: "rgba(235,229,214,0.18)",
    accent: "#d96b52", accent2: "#7fa67d",
    chip: "#2a261d", pos: "#7fa67d", neg: "#d96b52",
  },
};

// ── Shared atoms ──────────────────────────────────────
const Rule = ({ t, soft }) => <div style={{ height: 1, background: soft ? t.ruleSoft : t.rule }} />;
const DoubleRule = ({ t }) => <div style={{ borderTop: `3px solid ${t.rule}`, borderBottom: `1px solid ${t.rule}`, height: 5 }} />;
const Kicker = ({ t, children, color }) => (
  <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.22em", color: color || t.inkMuted, textTransform: "uppercase" }}>{children}</div>
);
const SectionHeader = ({ t, kicker, title, right }) => (
  <div style={{ marginBottom: 14 }}>
    <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 8 }}>
      <Kicker t={t}>{kicker}</Kicker>
      {right}
    </div>
    <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 32, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1, marginBottom: 10 }}>{title}</div>
    <DoubleRule t={t} />
  </div>
);
const btnA = (t) => ({
  display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 12px",
  background: t.ink, color: t.paper, border: "none", cursor: "pointer",
  fontFamily: '"JetBrains Mono", monospace', fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase",
});
const Stat = ({ t, label, big, sub, accent, last }) => (
  <div style={{ padding: "16px 20px", borderRight: last ? "none" : `1px solid ${t.ruleSoft}` }}>
    <Kicker t={t}>{label}</Kicker>
    <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 44, fontWeight: 700, lineHeight: 1, letterSpacing: "-0.03em", color: accent ? t.accent : t.ink, margin: "8px 0 4px" }}>{big}</div>
    <div style={{ fontSize: 12, color: t.inkMuted, fontStyle: "italic" }}>{sub}</div>
  </div>
);
const calcStreak = (h) => {
  let s = 0;
  for (let i = 0; i < 100; i++) {
    if (h.log && h.log[D_S.dKey(-i)]) s++; else break;
  }
  return s;
};

// ── Sidebar ───────────────────────────────────────────
const Sidebar = ({ t, page, setPage, theme, setTheme }) => {
  const items = [
    { id: "morning", label: "Morning", icon: "sun", section: "TODAY" },
    { id: "todos", label: "Tasks", icon: "checkSquare", section: "WORK" },
    { id: "habits", label: "Habits", icon: "flame", section: "WORK" },
    { id: "goals", label: "Goals", icon: "target", section: "WORK" },
    { id: "athletic", label: "Athletic", icon: "dumbbell", section: "BODY" },
    { id: "finance", label: "Finance", icon: "wallet", section: "MONEY" },
    { id: "business", label: "Ventures", icon: "rocket", section: "BUILD" },
    { id: "integrations", label: "Wires", icon: "link", section: "SYSTEM" },
  ];
  let lastSection = null;
  return (
    <aside style={{ background: t.paperAlt, borderRight: `1px solid ${t.ruleSoft}`, padding: "20px 0", display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "0 20px 18px", borderBottom: `1px solid ${t.ruleSoft}`, marginBottom: 14 }}>
        <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, lineHeight: 1, letterSpacing: "-0.02em" }}>
          Organized<br/><em style={{ color: t.accent, fontStyle: "italic" }}>Life</em>
        </div>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.18em", color: t.inkMuted, marginTop: 8, textTransform: "uppercase" }}>
          Vol. III · No. {new Date().getDate()}
        </div>
      </div>
      <nav style={{ flex: 1, padding: "0 12px" }}>
        {items.map((item) => {
          const showSection = item.section !== lastSection;
          lastSection = item.section;
          return (
            <React.Fragment key={item.id}>
              {showSection && (
                <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.2em", color: t.inkMuted, padding: "12px 8px 4px" }}>
                  {item.section}
                </div>
              )}
              <button
                onClick={() => setPage(item.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 10, width: "100%",
                  padding: "8px 10px", background: page === item.id ? t.ink : "transparent",
                  color: page === item.id ? t.paper : t.ink,
                  border: "none", textAlign: "left", cursor: "pointer",
                  fontFamily: 'inherit', fontSize: 14, fontWeight: 500,
                  borderRadius: 0, marginBottom: 1,
                }}
              >
                <Icon_S name={item.icon} size={15} stroke={1.4} />
                <span>{item.label}</span>
              </button>
            </React.Fragment>
          );
        })}
      </nav>
      <div style={{ padding: "12px 20px", borderTop: `1px solid ${t.ruleSoft}` }}>
        <button
          onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: `1px solid ${t.ruleSoft}`, color: t.inkSoft, padding: "6px 10px", cursor: "pointer", fontFamily: '"JetBrains Mono", monospace', fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", width: "100%" }}
        >
          <Icon_S name={theme === "light" ? "moon" : "sun"} size={12} stroke={1.5} />
          {theme === "light" ? "Night Edition" : "Day Edition"}
        </button>
      </div>
    </aside>
  );
};

// ── App shell ─────────────────────────────────────────
const EditorialApp = ({ initialPage = "morning", initialTheme = "light", scale = 1 }) => {
  const [page, setPage] = useStateS(initialPage);
  const [theme, setTheme] = useStateS(initialTheme);
  const [data, setData] = useStateS(window.OL_DATA_LAYER.get());
  useEffectS(() => window.OL_DATA_LAYER.subscribe(setData), []);

  const t = editorialTokens[theme];
  if (!data) return null;

  const containerStyle = {
    width: 1280, height: 820,
    background: t.paper, color: t.ink,
    fontFamily: '"Source Serif Pro", "Source Serif 4", Georgia, serif',
    display: "flex", flexDirection: "column",
    overflow: "hidden", position: "relative",
    transform: `scale(${scale})`, transformOrigin: "top left",
  };

  const pages = window.OL_PAGES;
  return (
    <div style={containerStyle}>
      <window.TechTopBar accent={t.accent} bg={t.paperAlt} text={t.ink} textMuted={t.inkMuted} variant="editorial" />
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "180px 1fr", overflow: "hidden", position: "relative" }}>
        <Sidebar t={t} page={page} setPage={setPage} theme={theme} setTheme={setTheme} />
        <main style={{ overflow: "auto", padding: 0, position: "relative" }}>
          <window.Fiducial position="tr" color={t.ruleSoft} />
          <window.Fiducial position="br" color={t.ruleSoft} />
          {page === "morning" && <pages.MorningPage t={t} data={data} />}
          {page === "todos" && <pages.TodosPage t={t} data={data} />}
          {page === "habits" && <pages.HabitsPage t={t} data={data} />}
          {page === "goals" && <pages.GoalsPage t={t} data={data} />}
          {page === "athletic" && <pages.AthleticPage t={t} data={data} />}
          {page === "finance" && <pages.FinancePage t={t} data={data} />}
          {page === "business" && <pages.BusinessPage t={t} data={data} />}
          {page === "integrations" && <pages.IntegrationsPage t={t} data={data} />}
        </main>
      </div>
      <window.TechBottomBar accent={t.accent} bg={t.paperAlt} text={t.ink} textMuted={t.inkMuted} page={page} />
    </div>
  );
};

window.EditorialApp = EditorialApp;
window.OL_SHELL = { Rule, DoubleRule, Kicker, SectionHeader, btnA, Stat, calcStreak, editorialTokens };
