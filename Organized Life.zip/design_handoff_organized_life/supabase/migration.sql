-- Organized Life — Supabase schema
-- Run once in the Supabase SQL editor. All tables are user-scoped via RLS.
-- Auth: assumes you're using Supabase Auth. Every row has a user_id pointing to auth.users.

-- ── Extensions ─────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── Helper: updated_at trigger ────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

-- ── Tasks ──────────────────────────────────────────────
create table if not exists public.tasks (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  text        text not null,
  priority    text not null default 'med' check (priority in ('high','med','low')),
  due         date,
  done        boolean not null default false,
  project     text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists tasks_user_idx on public.tasks(user_id, done, priority);
create trigger tasks_updated before update on public.tasks
  for each row execute function public.set_updated_at();

-- ── Habits ─────────────────────────────────────────────
create table if not exists public.habits (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  name        text not null,
  icon        text not null default 'circle',
  color       text not null default 'rust',
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists habits_user_idx on public.habits(user_id, sort_order);
create trigger habits_updated before update on public.habits
  for each row execute function public.set_updated_at();

-- ── Habit logs (one row per habit per day) ────────────
create table if not exists public.habit_logs (
  id        uuid primary key default uuid_generate_v4(),
  user_id   uuid not null references auth.users(id) on delete cascade,
  habit_id  uuid not null references public.habits(id) on delete cascade,
  date      date not null,
  done      boolean not null default true,
  created_at timestamptz not null default now(),
  unique (habit_id, date)
);
create index if not exists habit_logs_user_date_idx on public.habit_logs(user_id, date);
create index if not exists habit_logs_habit_idx on public.habit_logs(habit_id, date);

-- ── Goals ──────────────────────────────────────────────
create table if not exists public.goals (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  title       text not null,
  category    text not null default 'Personal',
  target_date date,
  progress    int  not null default 0 check (progress between 0 and 100),
  description text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists goals_user_idx on public.goals(user_id);
create trigger goals_updated before update on public.goals
  for each row execute function public.set_updated_at();

-- ── Workouts ───────────────────────────────────────────
create table if not exists public.workouts (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  type       text not null,
  duration   int  not null default 0,
  date       date not null default current_date,
  notes      text,
  created_at timestamptz not null default now()
);
create index if not exists workouts_user_idx on public.workouts(user_id, date desc);

-- ── Personal records ───────────────────────────────────
create table if not exists public.prs (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  exercise   text not null,
  value      text not null,  -- text so we can store "5:48" or "315"
  unit       text not null default 'lbs',
  date       date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists prs_user_idx on public.prs(user_id, date desc);

-- ── Body metrics (single-row settings, JSON for flexibility) ──
create table if not exists public.metrics (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  weight     numeric,
  body_fat   numeric,
  height     numeric,
  resting_hr int,
  updated_at timestamptz not null default now()
);
create trigger metrics_updated before update on public.metrics
  for each row execute function public.set_updated_at();

-- ── Transactions ───────────────────────────────────────
create table if not exists public.transactions (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  description text not null,
  amount     numeric not null,
  type       text not null check (type in ('income','expense')),
  category   text,
  date       date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists tx_user_idx on public.transactions(user_id, date desc);

-- ── Budgets ────────────────────────────────────────────
create table if not exists public.budgets (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  name       text not null,
  monthly_limit numeric not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger budgets_updated before update on public.budgets
  for each row execute function public.set_updated_at();

-- ── Accounts ───────────────────────────────────────────
create table if not exists public.accounts (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  name       text not null,
  type       text not null,
  balance    numeric not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger accounts_updated before update on public.accounts
  for each row execute function public.set_updated_at();

-- ── Ideas ──────────────────────────────────────────────
create table if not exists public.ideas (
  id         uuid primary key default uuid_generate_v4(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  title      text not null,
  description text,
  status     text not null default 'idea' check (status in ('idea','progress','validated')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ideas_user_idx on public.ideas(user_id, status);
create trigger ideas_updated before update on public.ideas
  for each row execute function public.set_updated_at();

-- ╔══════════════════════════════════════════════════════╗
-- ║ Row Level Security                                   ║
-- ╚══════════════════════════════════════════════════════╝

alter table public.tasks        enable row level security;
alter table public.habits       enable row level security;
alter table public.habit_logs   enable row level security;
alter table public.goals        enable row level security;
alter table public.workouts     enable row level security;
alter table public.prs          enable row level security;
alter table public.metrics      enable row level security;
alter table public.transactions enable row level security;
alter table public.budgets      enable row level security;
alter table public.accounts     enable row level security;
alter table public.ideas        enable row level security;

-- Generic "user can do anything to their own rows" policies
do $$
declare tbl text;
begin
  for tbl in select unnest(array['tasks','habits','habit_logs','goals','workouts','prs','transactions','budgets','accounts','ideas']) loop
    execute format('drop policy if exists %I_owner on public.%I', tbl, tbl);
    execute format('create policy %I_owner on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', tbl, tbl);
  end loop;
end $$;

drop policy if exists metrics_owner on public.metrics;
create policy metrics_owner on public.metrics for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
