// ed-pages.jsx — all 8 pages wired to dataLayer + modal CRUD.

(function () {
  const { useState, useMemo } = React;
  const D = window.OL_DATA;
  const DL = window.OL_DATA_LAYER;
  const Icon = window.Icon;
  const M = window.OL_MODALS;
  const { Rule, DoubleRule, Kicker, SectionHeader, btnA, Stat, calcStreak } = window.OL_SHELL;

  // ── Morning ──────────────────────────────────────────
  const MorningPage = ({ t, data }) => {
    const today = D.todayKey();
    const now = new Date();
    const date = now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" }).toUpperCase();
    const greet = now.getHours() < 12 ? "Good morning" : now.getHours() < 17 ? "Good afternoon" : "Good evening";
    const habits = data.habits;
    const habitsToday = habits.filter(h => h.log && h.log[today]).length;
    const highTodos = data.tasks.filter(x => x.priority === "high" && !x.done);
    const quote = D.QUOTES[now.getDate() % D.QUOTES.length];

    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <div style={{ borderTop: `4px solid ${t.rule}`, borderBottom: `1px solid ${t.rule}`, padding: "10px 0", display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: '"JetBrains Mono", monospace', fontSize: 10, letterSpacing: "0.18em" }}>
          <span>{date}</span>
          <span style={{ color: t.accent }}>★ THE PERSONAL EDITION ★</span>
          <span>72°F · CLEAR · 40.71°N 74.01°W</span>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", borderBottom: `1px solid ${t.ruleSoft}`, fontFamily: '"JetBrains Mono", monospace' }}>
          {[
            { l: "SLEEP", v: "7h12m", s: "86%", spark: [4,5,3,6,7,5,7] },
            { l: "HRV", v: "64ms", s: "+8 7d", spark: [3,4,5,4,6,5,7] },
            { l: "FOCUS", v: "3h18m", s: "DEEP", spark: [2,4,3,5,4,6,7] },
            { l: "STEPS", v: "8,420", s: "→ 10K", spark: [5,3,6,4,7,5,6] },
            { l: "API", v: "247ms", s: "P99", spark: [3,3,4,3,3,4,3] },
            { l: "STREAK", v: `${Math.max(0, ...habits.map(calcStreak))}d`, s: "RITUALS", spark: [3,4,5,5,6,6,7] },
          ].map((m, i) => (
            <div key={i} style={{ padding: "8px 12px", borderRight: i < 5 ? `1px solid ${t.ruleSoft}` : "none", display: "flex", flexDirection: "column", gap: 2 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <span style={{ fontSize: 8, letterSpacing: "0.2em", color: t.inkMuted }}>{m.l}</span>
                <span style={{ fontSize: 8, color: t.accent, letterSpacing: "0.1em" }}>{m.s}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>{m.v}</span>
                <span style={{ display: "flex", gap: 1, alignItems: "flex-end", height: 14 }}>
                  {m.spark.map((h, j) => <span key={j} style={{ width: 2, height: h * 1.8, background: j === 6 ? t.accent : t.inkSoft }} />)}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div style={{ padding: "28px 0 24px", borderBottom: `1px solid ${t.rule}` }}>
          <Kicker t={t} color={t.accent}>FROM THE DESK OF PAUL</Kicker>
          <h1 style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 76, fontWeight: 800, lineHeight: 0.95, letterSpacing: "-0.035em", margin: "10px 0 6px", textWrap: "balance" }}>
            {greet}.<br/>
            <em style={{ fontStyle: "italic", color: t.accent }}>It is a fine day to ship.</em>
          </h1>
          <div style={{ fontStyle: "italic", color: t.inkSoft, fontSize: 16, maxWidth: 720, lineHeight: 1.5 }}>
            {habitsToday} of {habits.length} habits already logged. {highTodos.length} headline tasks await your attention. {DL.isCloud() ? "Synced." : "On local edition — sign in to sync."}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1px 1fr 1px 1fr", gap: 24, paddingTop: 24 }}>
          <div>
            <Kicker t={t} color={t.accent}>LEAD STORY · TODAY'S FOCUS</Kicker>
            <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 26, fontWeight: 700, lineHeight: 1.15, letterSpacing: "-0.015em", margin: "8px 0 12px" }}>
              Close the Series A by Friday. Everything else is noise.
            </div>
            <div style={{ fontSize: 14, lineHeight: 1.55, columnCount: 2, columnGap: 18, color: t.ink }}>
              <p style={{ marginBottom: 10 }}>The Sequoia call is at 3:00. The deck is at 87% — three slides need numbers, two need a story. Anya's PR unblocks the auth flow demo. Lunch with Priya can run long; the call cannot.</p>
              <p>Tonight is dinner at Cosme. Tomorrow is a long run. Between now and Friday: the deck, the call, and one quiet hour of writing each morning. Nothing else qualifies.</p>
            </div>
            <div style={{ marginTop: 22, padding: "14px 0", borderTop: `1px solid ${t.rule}`, borderBottom: `1px solid ${t.rule}` }}>
              <Kicker t={t}>DISPATCHES · UPCOMING</Kicker>
              <div style={{ marginTop: 10 }}>
                {D.SEED_EVENTS.map((e, i) => (
                  <div key={i} style={{ display: "grid", gridTemplateColumns: "60px 1fr auto", gap: 12, padding: "7px 0", borderBottom: i < D.SEED_EVENTS.length - 1 ? `1px dotted ${t.ruleSoft}` : "none", alignItems: "baseline" }}>
                    <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, color: t.accent, letterSpacing: "0.05em" }}>{e.time}</span>
                    <span style={{ fontSize: 14 }}>{e.title}</span>
                    <span style={{ fontSize: 11, color: t.inkMuted, fontStyle: "italic" }}>{e.sub}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div style={{ background: t.ruleSoft }} />

          <div>
            <Kicker t={t} color={t.accent}>RITUALS</Kicker>
            <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, margin: "8px 0 10px", letterSpacing: "-0.01em" }}>The Daily Practice</div>
            <Rule t={t} />
            <div style={{ marginTop: 8 }}>
              {habits.slice(0, 6).map((h) => {
                const done = !!(h.log && h.log[today]);
                return (
                  <div key={h.id} onClick={() => DL.toggleHabitDay(h.id, today)}
                    style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 0", borderBottom: `1px dotted ${t.ruleSoft}`, cursor: "pointer" }}>
                    <span style={{ width: 16, height: 16, border: `1.5px solid ${t.ink}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      {done && <Icon name="check" size={11} stroke={2.5} />}
                    </span>
                    <span style={{ fontSize: 14, flex: 1, textDecoration: done ? "line-through" : "none", color: done ? t.inkMuted : t.ink }}>{h.name}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ marginTop: 18 }}>
              <Kicker t={t} color={t.accent}>NOW PLAYING</Kicker>
              <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8, padding: "10px 0", borderBottom: `1px solid ${t.rule}`, borderTop: `1px solid ${t.rule}` }}>
                <div style={{ width: 38, height: 38, background: t.chip, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon name="music" size={18} stroke={1.5} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, fontStyle: "italic" }}>{D.SEED_NOW_PLAYING.track}</div>
                  <div style={{ fontSize: 11, color: t.inkMuted }}>{D.SEED_NOW_PLAYING.artist} · {D.SEED_NOW_PLAYING.album}</div>
                </div>
                <Icon name="pause" size={14} stroke={1.5} style={{ color: t.accent }} />
              </div>
            </div>
          </div>

          <div style={{ background: t.ruleSoft }} />

          <div>
            <Kicker t={t} color={t.accent}>HEADLINE TASKS</Kicker>
            <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, margin: "8px 0 10px", letterSpacing: "-0.01em" }}>Front Page</div>
            <Rule t={t} />
            {highTodos.slice(0, 4).map((td, i) => (
              <div key={td.id} style={{ padding: "10px 0", borderBottom: `1px dotted ${t.ruleSoft}` }}>
                <div style={{ display: "flex", gap: 8, fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.accent, letterSpacing: "0.1em", marginBottom: 4 }}>
                  <span>№ {String(i + 1).padStart(2, "0")}</span>
                  <span style={{ color: t.inkMuted }}>· {td.project}</span>
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.35, fontWeight: 500 }}>{td.text}</div>
              </div>
            ))}
            <div style={{ marginTop: 22, padding: "16px 14px", background: t.paperAlt, border: `1px solid ${t.rule}` }}>
              <Kicker t={t}>EDITORIAL</Kicker>
              <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 16, fontStyle: "italic", lineHeight: 1.4, margin: "10px 0", color: t.ink }}>"{quote.q}"</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: t.accent, letterSpacing: "0.1em" }}>— {quote.a.toUpperCase()}</div>
            </div>
            <div style={{ marginTop: 18 }}>
              <Kicker t={t}>CORRESPONDENCE</Kicker>
              <div style={{ marginTop: 6 }}>
                {D.SEED_EMAILS.slice(0, 3).map((e, i) => (
                  <div key={i} style={{ padding: "7px 0", borderBottom: `1px dotted ${t.ruleSoft}`, fontSize: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ fontWeight: e.unread ? 700 : 400, fontStyle: "italic" }}>{e.from}</span>
                      <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted }}>{e.time}</span>
                    </div>
                    <div style={{ color: t.inkSoft, fontSize: 12, marginTop: 2 }}>{e.subject}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ── Tasks ────────────────────────────────────────────
  const TodosPage = ({ t, data }) => {
    const [editing, setEditing] = useState(null); // null | "new" | task
    const todos = data.tasks;
    const groups = { high: todos.filter(x => x.priority === "high" && !x.done), med: todos.filter(x => x.priority === "med" && !x.done), low: todos.filter(x => x.priority === "low" && !x.done) };
    const done = todos.filter(x => x.done);

    const PriorityCol = ({ label, items, num }) => (
      <div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", padding: "6px 0", borderBottom: `2px solid ${t.rule}` }}>
          <Kicker t={t} color={t.accent}>{num} · {label}</Kicker>
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, color: t.inkSoft }}>{items.length}</span>
        </div>
        {items.map((td) => (
          <div key={td.id} style={{ padding: "10px 0", borderBottom: `1px dotted ${t.ruleSoft}`, display: "flex", gap: 10, alignItems: "flex-start" }}>
            <span onClick={(e) => { e.stopPropagation(); DL.toggleTask(td.id); }}
              style={{ width: 14, height: 14, border: `1.5px solid ${t.ink}`, marginTop: 3, flexShrink: 0, cursor: "pointer" }} />
            <div style={{ flex: 1, cursor: "pointer" }} onClick={() => setEditing(td)}>
              <div style={{ fontSize: 14, lineHeight: 1.35 }}>{td.text}</div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted, letterSpacing: "0.1em", marginTop: 4 }}>
                {td.project?.toUpperCase()} {td.due && `· DUE ${td.due}`}
              </div>
            </div>
          </div>
        ))}
        {!items.length && <div style={{ padding: "14px 0", fontStyle: "italic", color: t.inkMuted, fontSize: 13 }}>— Nothing in queue —</div>}
      </div>
    );

    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker={`SECTION B · ${todos.filter(x => !x.done).length} OPEN`} title="Tasks & Affairs"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> File new task</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 24 }}>
          <PriorityCol label="URGENT" items={groups.high} num="I" />
          <PriorityCol label="STANDARD" items={groups.med} num="II" />
          <PriorityCol label="DEFERRED" items={groups.low} num="III" />
        </div>
        <div style={{ marginTop: 28 }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", padding: "6px 0", borderBottom: `2px solid ${t.rule}` }}>
            <Kicker t={t}>SETTLED · {done.length}</Kicker>
          </div>
          <div style={{ marginTop: 6 }}>
            {done.map((td) => (
              <div key={td.id} onClick={() => DL.toggleTask(td.id)} style={{ padding: "8px 0", borderBottom: `1px dotted ${t.ruleSoft}`, display: "flex", gap: 10, color: t.inkMuted, textDecoration: "line-through", cursor: "pointer" }}>
                <Icon name="check" size={14} stroke={1.8} style={{ color: t.accent2, marginTop: 2 }} />
                <span style={{ fontSize: 13 }}>{td.text}</span>
              </div>
            ))}
          </div>
        </div>
        {editing && (
          <M.TaskModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { editing === "new" ? DL.addTask(payload) : DL.updateTask(editing.id, payload); setEditing(null); }}
            onDelete={() => { DL.deleteTask(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Habits ───────────────────────────────────────────
  const HabitsPage = ({ t, data }) => {
    const [editing, setEditing] = useState(null);
    const today = D.todayKey();
    const week = Array.from({ length: 7 }, (_, i) => D.dKey(-(6 - i)));
    const dayLabels = week.map(d => new Date(d + "T12:00:00").toLocaleDateString("en-US", { weekday: "narrow" }));
    const habits = data.habits;
    const todayDone = habits.filter(h => h.log && h.log[today]).length;
    const pct = habits.length ? Math.round((todayDone / habits.length) * 100) : 0;
    const longest = habits.length ? Math.max(...habits.map(calcStreak)) : 0;
    const weekScore = habits.length ? Math.round(habits.reduce((s, h) => s + week.filter(d => h.log && h.log[d]).length, 0) / (habits.length * 7) * 100) : 0;

    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION C · DAILY PRACTICE" title="The Habit Ledger"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> Declare ritual</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr 1fr 1fr", borderBottom: `2px solid ${t.rule}`, marginBottom: 24 }}>
          <Stat t={t} label="TODAY'S COMPLETION" big={`${pct}%`} sub={`${todayDone} of ${habits.length} rituals observed`} accent />
          <Stat t={t} label="LONGEST STREAK" big={longest} sub="consecutive days" />
          <Stat t={t} label="TOTAL RITUALS" big={habits.length} sub="under observation" />
          <Stat t={t} label="WEEK SCORE" big={`${weekScore}%`} sub="trailing seven-day average" last />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "180px 1fr repeat(7, 32px) 50px", gap: 8, alignItems: "center", padding: "6px 0", borderBottom: `1px solid ${t.rule}`, marginBottom: 4 }}>
          <Kicker t={t}>RITUAL</Kicker>
          <Kicker t={t}>STREAK</Kicker>
          {dayLabels.map((d, i) => <div key={i} style={{ textAlign: "center", fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: i === 6 ? t.accent : t.inkMuted, letterSpacing: "0.1em" }}>{d}</div>)}
          <Kicker t={t}>%</Kicker>
        </div>
        {habits.map((h) => {
          const streak = calcStreak(h);
          const weekDone = week.filter(d => h.log && h.log[d]).length;
          return (
            <div key={h.id} style={{ display: "grid", gridTemplateColumns: "180px 1fr repeat(7, 32px) 50px", gap: 8, alignItems: "center", padding: "12px 0", borderBottom: `1px dotted ${t.ruleSoft}` }}>
              <div onClick={() => setEditing(h)} style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
                <Icon name={h.icon} size={15} stroke={1.5} style={{ color: t.accent }} />
                <span style={{ fontSize: 14, fontWeight: 500 }}>{h.name}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ flex: 1, height: 6, background: t.chip, position: "relative" }}>
                  <div style={{ position: "absolute", inset: 0, width: `${Math.min(100, streak * 10)}%`, background: t.accent }} />
                </div>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 12, color: streak > 0 ? t.accent : t.inkMuted, minWidth: 20 }}>{streak}d</span>
              </div>
              {week.map((d) => {
                const done = !!(h.log && h.log[d]);
                const isToday = d === today;
                return (
                  <div key={d} onClick={() => DL.toggleHabitDay(h.id, d)}
                    style={{ width: 26, height: 26, border: `1.5px solid ${isToday ? t.accent : t.rule}`, background: done ? t.ink : "transparent", color: done ? t.paper : "transparent", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", margin: "0 auto" }}>
                    {done && <Icon name="check" size={12} stroke={2.5} />}
                  </div>
                );
              })}
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 12, color: t.inkSoft, textAlign: "right" }}>{Math.round(weekDone / 7 * 100)}</div>
            </div>
          );
        })}
        {editing && (
          <M.HabitModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { editing === "new" ? DL.addHabit(payload) : DL.updateHabit(editing.id, payload); setEditing(null); }}
            onDelete={() => { DL.deleteHabit(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Goals ────────────────────────────────────────────
  const GoalsPage = ({ t, data }) => {
    const [editing, setEditing] = useState(null);
    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION D · LONG VIEW" title="Goals & Ambitions"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> Declare goal</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, borderTop: `1px solid ${t.rule}` }}>
          {data.goals.map((g, i) => (
            <div key={g.id} onClick={() => setEditing(g)} style={{ padding: "20px 24px", borderBottom: `1px solid ${t.ruleSoft}`, borderRight: i % 2 === 0 ? `1px solid ${t.ruleSoft}` : "none", cursor: "pointer" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
                <Kicker t={t} color={t.accent}>{(g.category || "").toUpperCase()}</Kicker>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: t.inkMuted }}>BY {g.date}</span>
              </div>
              <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, lineHeight: 1.1, letterSpacing: "-0.015em", marginBottom: 8 }}>{g.title}</div>
              <div style={{ fontSize: 13, color: t.inkSoft, fontStyle: "italic", marginBottom: 14, lineHeight: 1.5 }}>{g.desc}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ flex: 1, height: 8, background: t.chip, position: "relative" }}>
                  <div style={{ position: "absolute", inset: 0, width: `${g.progress}%`, background: t.accent }} />
                  <div style={{ position: "absolute", left: 0, right: 0, top: -4, bottom: -4, borderTop: `1px solid ${t.rule}`, borderBottom: `1px solid ${t.rule}` }} />
                </div>
                <span style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 28, fontWeight: 700, color: t.ink, letterSpacing: "-0.02em" }}>{g.progress}<span style={{ fontSize: 14, color: t.inkMuted }}>%</span></span>
              </div>
            </div>
          ))}
        </div>
        {editing && (
          <M.GoalModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { editing === "new" ? DL.addGoal(payload) : DL.updateGoal(editing.id, payload); setEditing(null); }}
            onDelete={() => { DL.deleteGoal(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Athletic ─────────────────────────────────────────
  const AthleticPage = ({ t, data }) => {
    const [editing, setEditing] = useState(null);
    const m = data.metrics;
    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION E · BODY DEPT." title="The Athletic Page"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> Log session</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", borderBottom: `2px solid ${t.rule}`, marginBottom: 24 }}>
          <Stat t={t} label="WEIGHT (LB)" big={m.weight} sub="↓ 1.2 lb / 30 days" accent />
          <Stat t={t} label="BODY FAT %" big={m.bf} sub="trending down" />
          <Stat t={t} label="RESTING HR" big={m.hr} sub="bpm · excellent" />
          <Stat t={t} label="WEEK STREAK" big="6" sub="consecutive sessions" last />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28, marginBottom: 28 }}>
          <div>
            <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 6 }}>
              <Kicker t={t} color={t.accent}>PERSONAL RECORDS · CURRENT</Kicker>
            </div>
            {data.prs.map((pr) => (
              <div key={pr.id} style={{ padding: "12px 0", borderBottom: `1px dotted ${t.ruleSoft}`, display: "grid", gridTemplateColumns: "1fr auto auto", alignItems: "baseline", gap: 12 }}>
                <span style={{ fontSize: 15, fontWeight: 500 }}>{pr.exercise}</span>
                <span style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, color: t.accent, letterSpacing: "-0.015em" }}>{pr.value}<span style={{ fontSize: 12, color: t.inkMuted, marginLeft: 4 }}>{pr.unit}</span></span>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted, letterSpacing: "0.1em" }}>{pr.date}</span>
              </div>
            ))}
          </div>
          <div>
            <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 16 }}>
              <Kicker t={t} color={t.accent}>WEEKLY VOLUME · MINUTES</Kicker>
            </div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 180, padding: "0 4px" }}>
              {[280, 245, 310, 290, 260, 320, 295, 270, 340, 280, 310, 295].map((v, i) => (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                  <div style={{ flex: 1, width: "100%", display: "flex", alignItems: "flex-end" }}>
                    <div style={{ width: "100%", height: `${v / 4}px`, background: i === 11 ? t.accent : t.ink, opacity: i === 11 ? 1 : 0.85 }} />
                  </div>
                  <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted }}>W{i + 1}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div>
          <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 6 }}>
            <Kicker t={t} color={t.accent}>SESSION LOG · LAST 7 DAYS</Kicker>
          </div>
          {data.workouts.map((w) => (
            <div key={w.id} onClick={() => setEditing(w)} style={{ padding: "14px 0", borderBottom: `1px dotted ${t.ruleSoft}`, display: "grid", gridTemplateColumns: "100px 1fr auto", gap: 16, alignItems: "baseline", cursor: "pointer" }}>
              <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: t.inkMuted, letterSpacing: "0.1em" }}>{w.date}</span>
              <div>
                <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 17, fontWeight: 700, fontStyle: "italic", marginBottom: 2 }}>{w.type}</div>
                <div style={{ fontSize: 13, color: t.inkSoft, lineHeight: 1.5 }}>{w.notes}</div>
              </div>
              <span style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 22, fontWeight: 700, color: t.accent }}>{w.duration}<span style={{ fontSize: 11, color: t.inkMuted, marginLeft: 4 }}>min</span></span>
            </div>
          ))}
        </div>
        {editing && (
          <M.WorkoutModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { editing === "new" ? DL.addWorkout(payload) : DL.deleteWorkout(editing.id) || DL.addWorkout(payload); setEditing(null); }}
            onDelete={() => { DL.deleteWorkout(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Finance ──────────────────────────────────────────
  const FinancePage = ({ t, data }) => {
    const [editing, setEditing] = useState(null);
    const tx = data.transactions;
    const income = tx.filter(x => x.type === "income").reduce((s, x) => s + Number(x.amount), 0);
    const spend = tx.filter(x => x.type === "expense").reduce((s, x) => s + Number(x.amount), 0);
    const net = data.accounts.reduce((s, a) => s + Number(a.balance), 0);
    const savingsRate = income > 0 ? Math.round((income - spend) / income * 100) : 0;

    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION F · MONEY DESK" title="The Ledger"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> Record entry</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", borderBottom: `2px solid ${t.rule}`, marginBottom: 24 }}>
          <Stat t={t} label="NET WORTH" big={`$${(net / 1000).toFixed(1)}K`} sub="↑ 3.2% MoM" accent />
          <Stat t={t} label="INCOME · MTD" big={`$${(income / 1000).toFixed(1)}K`} sub="2 sources" />
          <Stat t={t} label="OUTLAY · MTD" big={`$${(spend / 1000).toFixed(1)}K`} sub="below budget" />
          <Stat t={t} label="SAVINGS RATE" big={`${savingsRate}%`} sub="of gross income" last />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 28, marginBottom: 28 }}>
          <div>
            <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 6 }}>
              <Kicker t={t} color={t.accent}>TRANSACTIONS · LAST 14 DAYS</Kicker>
            </div>
            {tx.map((x) => (
              <div key={x.id} onClick={() => setEditing(x)} style={{ padding: "11px 0", borderBottom: `1px dotted ${t.ruleSoft}`, display: "grid", gridTemplateColumns: "80px 1fr 100px 110px", gap: 12, alignItems: "baseline", cursor: "pointer" }}>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 10, color: t.inkMuted }}>{(x.date || "").slice(5)}</span>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{x.desc}</div>
                  <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted, letterSpacing: "0.1em", marginTop: 2 }}>{(x.category || "").toUpperCase()}</div>
                </div>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, color: t.inkMuted, textAlign: "right" }}>{x.type === "income" ? "CR" : "DR"}</span>
                <span style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 17, fontWeight: 700, textAlign: "right", color: x.type === "income" ? t.pos : t.ink }}>
                  {x.type === "income" ? "+" : "−"}${Number(x.amount).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
          <div>
            <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 14 }}>
              <Kicker t={t} color={t.accent}>BUDGET · APRIL</Kicker>
            </div>
            {data.budgets.map((b) => {
              const limit = b.monthly_limit || b.limit || 0;
              const pct = limit ? Math.round((b.spent || 0) / limit * 100) : 0;
              const over = pct > 90;
              return (
                <div key={b.id || b.name} style={{ marginBottom: 16 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 4 }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{b.name}</span>
                    <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11, color: over ? t.neg : t.inkSoft }}>${(b.spent || 0).toFixed(0)} / ${limit}</span>
                  </div>
                  <div style={{ height: 6, background: t.chip, position: "relative" }}>
                    <div style={{ position: "absolute", inset: 0, width: `${Math.min(100, pct)}%`, background: over ? t.neg : t.ink }} />
                  </div>
                </div>
              );
            })}
            <div style={{ marginTop: 24 }}>
              <div style={{ borderBottom: `2px solid ${t.rule}`, paddingBottom: 6, marginBottom: 14 }}>
                <Kicker t={t} color={t.accent}>HOLDINGS</Kicker>
              </div>
              {data.accounts.map((a) => (
                <div key={a.id || a.name} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px dotted ${t.ruleSoft}`, alignItems: "baseline" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{a.name}</div>
                    <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, color: t.inkMuted, letterSpacing: "0.1em" }}>{(a.type || "").toUpperCase()}</div>
                  </div>
                  <span style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 16, fontWeight: 700, color: a.balance < 0 ? t.neg : t.ink }}>
                    {a.balance < 0 ? "−" : ""}${Math.abs(a.balance).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        {editing && (
          <M.TransactionModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { if (editing === "new") DL.addTransaction(payload); else { DL.deleteTransaction(editing.id); DL.addTransaction(payload); } setEditing(null); }}
            onDelete={() => { DL.deleteTransaction(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Business ─────────────────────────────────────────
  const BusinessPage = ({ t, data }) => {
    const [editing, setEditing] = useState(null);
    const ideas = data.ideas;
    const cols = [
      { id: "idea", label: "I · IDEAS" },
      { id: "progress", label: "II · IN PROGRESS" },
      { id: "validated", label: "III · VALIDATED" },
    ];
    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION G · VENTURES" title="The Idea Stack"
          right={<button style={btnA(t)} onClick={() => setEditing("new")}><Icon name="plus" size={11} /> File idea</button>} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 0, borderTop: `1px solid ${t.rule}` }}>
          {cols.map((col, ci) => {
            const items = ideas.filter(x => x.status === col.id);
            return (
              <div key={col.id} style={{ padding: "20px 18px", borderRight: ci < 2 ? `1px solid ${t.ruleSoft}` : "none", borderBottom: `1px solid ${t.ruleSoft}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", paddingBottom: 8, borderBottom: `2px solid ${t.rule}`, marginBottom: 14 }}>
                  <Kicker t={t} color={t.accent}>{col.label}</Kicker>
                  <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11 }}>{items.length}</span>
                </div>
                {items.map((idea) => (
                  <div key={idea.id} onClick={() => setEditing(idea)} style={{ marginBottom: 18, paddingBottom: 14, borderBottom: `1px dotted ${t.ruleSoft}`, cursor: "pointer" }}>
                    <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 18, fontWeight: 700, lineHeight: 1.15, letterSpacing: "-0.01em", marginBottom: 6 }}>{idea.title}</div>
                    <div style={{ fontSize: 13, color: t.inkSoft, lineHeight: 1.5, fontStyle: "italic" }}>{idea.desc}</div>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
        {editing && (
          <M.IdeaModal t={t} initial={editing === "new" ? null : editing}
            onClose={() => setEditing(null)}
            onSave={(payload) => { editing === "new" ? DL.addIdea(payload) : DL.updateIdea(editing.id, payload); setEditing(null); }}
            onDelete={() => { DL.deleteIdea(editing.id); setEditing(null); }} />
        )}
      </div>
    );
  };

  // ── Wires ────────────────────────────────────────────
  const IntegrationsPage = ({ t, data }) => {
    const cloud = DL.isCloud();
    const services = [
      { name: "Supabase", desc: cloud ? "Connected — your data is syncing" : "Configured — sign in to sync (sign-in flow not yet wired)", icon: "link", connected: cloud, primary: true },
      { name: "Spotify", desc: "Now playing & playback control", icon: "music", connected: false },
      { name: "Gmail", desc: "Inbox preview on the morning page", icon: "mail", connected: false },
      { name: "Google Calendar", desc: "Today's dispatches", icon: "calendar", connected: false },
      { name: "GitHub", desc: "Open PRs & issue triage", icon: "link", connected: false },
      { name: "Strava", desc: "Auto-import runs & rides", icon: "trending", connected: false },
      { name: "Plaid", desc: "Bank balances & transactions", icon: "wallet", connected: false },
    ];
    return (
      <div style={{ padding: "28px 36px 36px" }}>
        <SectionHeader t={t} kicker="SECTION H · WIRES & WIRES" title="Connected Services" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, borderTop: `1px solid ${t.rule}` }}>
          {services.map((s, i) => (
            <div key={s.name} style={{ padding: "20px 24px", display: "flex", gap: 16, alignItems: "flex-start", borderBottom: `1px solid ${t.ruleSoft}`, borderRight: i % 2 === 0 ? `1px solid ${t.ruleSoft}` : "none", background: s.primary ? t.paperAlt : "transparent" }}>
              <div style={{ width: 40, height: 40, border: `1px solid ${t.rule}`, display: "flex", alignItems: "center", justifyContent: "center", background: t.paper, flexShrink: 0 }}>
                <Icon name={s.icon} size={18} stroke={1.5} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 18, fontWeight: 700 }}>{s.name}</div>
                  <Kicker t={t} color={s.connected ? t.pos : t.inkMuted}>{s.connected ? "● ACTIVE" : "○ DORMANT"}</Kicker>
                </div>
                <div style={{ fontSize: 13, color: t.inkSoft, fontStyle: "italic", margin: "4px 0 12px" }}>{s.desc}</div>
                <button style={s.connected ? { ...btnA(t), background: "transparent", color: t.ink, border: `1px solid ${t.rule}` } : btnA(t)}>
                  {s.connected ? "Disconnect" : "Connect"}
                </button>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 24, padding: "16px 20px", border: `1px solid ${t.ruleSoft}`, background: t.paperAlt, fontSize: 12, color: t.inkSoft, lineHeight: 1.6 }}>
          <Kicker t={t} color={t.accent}>STATUS</Kicker>
          <div style={{ marginTop: 6 }}>
            Backend: <strong>{cloud ? "Supabase (cloud)" : "Local cache only"}</strong>. Schema: <code style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 11 }}>supabase/migration.sql</code>. Run it in the Supabase SQL editor, then sign in to start syncing.
          </div>
          <button onClick={() => { if (confirm("Reset local data to seed?")) DL.resetLocal(); }}
            style={{ ...btnA(t), background: "transparent", color: t.ink, border: `1px solid ${t.ruleSoft}`, marginTop: 12 }}>
            Reset local cache
          </button>
        </div>
      </div>
    );
  };

  window.OL_PAGES = { MorningPage, TodosPage, HabitsPage, GoalsPage, AthleticPage, FinancePage, BusinessPage, IntegrationsPage };
})();
