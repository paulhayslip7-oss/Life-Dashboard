// modals.jsx — Editorial-styled modal CRUD forms.
// All modals use the same shell. Each form receives `initial` (or null = new) and `onSave`/`onClose`.

const useState = React.useState;

// ─── Shell ───────────────────────────────────────────
const Modal = ({ t, title, kicker, onClose, children, footer }) => (
  <div
    onClick={onClose}
    style={{
      position: "absolute", inset: 0, background: "rgba(20,18,15,0.55)",
      display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100,
      backdropFilter: "blur(2px)",
    }}
  >
    <div
      onClick={(e) => e.stopPropagation()}
      style={{
        width: 520, maxHeight: "85%", background: t.paper,
        border: `1px solid ${t.rule}`, color: t.ink,
        fontFamily: '"Source Serif Pro", Georgia, serif',
        display: "flex", flexDirection: "column",
        boxShadow: "0 30px 80px rgba(0,0,0,0.35)",
      }}
    >
      <div style={{ padding: "18px 24px 14px", borderBottom: `1px solid ${t.rule}` }}>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.22em", color: t.accent, textTransform: "uppercase", marginBottom: 4 }}>
          {kicker}
        </div>
        <div style={{ fontFamily: '"Source Serif Pro", Georgia, serif', fontSize: 28, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1 }}>
          {title}
        </div>
      </div>
      <div style={{ padding: "20px 24px", overflow: "auto", flex: 1 }}>{children}</div>
      <div style={{ padding: "14px 24px", borderTop: `1px solid ${t.rule}`, background: t.paperAlt, display: "flex", justifyContent: "flex-end", gap: 8 }}>
        {footer}
      </div>
    </div>
  </div>
);

const Field = ({ t, label, children }) => (
  <label style={{ display: "block", marginBottom: 14 }}>
    <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.2em", color: t.inkMuted, textTransform: "uppercase", marginBottom: 5 }}>{label}</div>
    {children}
  </label>
);

const inputStyle = (t) => ({
  width: "100%", padding: "8px 10px", fontFamily: 'inherit', fontSize: 15,
  background: t.paperAlt, color: t.ink, border: `1px solid ${t.ruleSoft}`, borderRadius: 0,
  outline: "none", boxSizing: "border-box",
});
const monoInput = (t) => ({ ...inputStyle(t), fontFamily: '"JetBrains Mono", monospace', fontSize: 13 });

const Btn = ({ t, primary, danger, children, ...rest }) => (
  <button
    {...rest}
    style={{
      padding: "7px 14px", border: "none", cursor: "pointer",
      fontFamily: '"JetBrains Mono", monospace', fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase",
      background: primary ? t.ink : (danger ? "transparent" : "transparent"),
      color: primary ? t.paper : (danger ? t.accent : t.ink),
      border: primary ? "none" : `1px solid ${danger ? t.accent : t.ruleSoft}`,
    }}
  >
    {children}
  </button>
);

// ─── Task ────────────────────────────────────────────
const TaskModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [text, setText] = useState(initial?.text || "");
  const [priority, setPriority] = useState(initial?.priority || "med");
  const [due, setDue] = useState(initial?.due || "");
  const [project, setProject] = useState(initial?.project || "Personal");
  return (
    <Modal t={t} kicker={initial ? "EDIT · TASK" : "FILE · NEW TASK"} title={initial ? "Revise entry" : "What needs doing?"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => text && onSave({ text, priority, due: due || null, project })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Headline"><input autoFocus style={inputStyle(t)} value={text} onChange={(e) => setText(e.target.value)} placeholder="Finish the deck…" /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Field t={t} label="Priority">
          <select style={inputStyle(t)} value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="high">I · Urgent</option><option value="med">II · Standard</option><option value="low">III · Deferred</option>
          </select>
        </Field>
        <Field t={t} label="Due"><input type="date" style={monoInput(t)} value={due || ""} onChange={(e) => setDue(e.target.value)} /></Field>
      </div>
      <Field t={t} label="Project / desk"><input style={inputStyle(t)} value={project} onChange={(e) => setProject(e.target.value)} /></Field>
    </Modal>
  );
};

// ─── Habit ───────────────────────────────────────────
const HabitModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [name, setName] = useState(initial?.name || "");
  const [icon, setIcon] = useState(initial?.icon || "circle");
  const icons = ["circle", "dumbbell", "moon", "sun", "flame", "list", "pen", "thermo", "music", "target", "check"];
  return (
    <Modal t={t} kicker={initial ? "EDIT · RITUAL" : "DECLARE · NEW RITUAL"} title={initial ? "Adjust the practice" : "A new daily practice"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => name && onSave({ name, icon })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Name"><input autoFocus style={inputStyle(t)} value={name} onChange={(e) => setName(e.target.value)} placeholder="Cold shower, meditate, write…" /></Field>
      <Field t={t} label="Icon">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(11, 1fr)", gap: 4 }}>
          {icons.map(i => (
            <button key={i} onClick={() => setIcon(i)} type="button"
              style={{ aspectRatio: "1", background: icon === i ? t.ink : t.paperAlt, color: icon === i ? t.paper : t.ink, border: `1px solid ${icon === i ? t.ink : t.ruleSoft}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <window.Icon name={i} size={14} stroke={1.5} />
            </button>
          ))}
        </div>
      </Field>
    </Modal>
  );
};

// ─── Goal ────────────────────────────────────────────
const GoalModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [title, setTitle] = useState(initial?.title || "");
  const [category, setCategory] = useState(initial?.category || "Personal");
  const [date, setDate] = useState(initial?.date || "");
  const [progress, setProgress] = useState(initial?.progress ?? 0);
  const [desc, setDesc] = useState(initial?.desc || "");
  return (
    <Modal t={t} kicker={initial ? "EDIT · GOAL" : "DECLARE · NEW GOAL"} title={initial ? "Refine the ambition" : "An ambition committed"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => title && onSave({ title, category, date, progress: Number(progress), desc })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Title"><input autoFocus style={inputStyle(t)} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Run a sub-4 marathon…" /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Field t={t} label="Category">
          <select style={inputStyle(t)} value={category} onChange={(e) => setCategory(e.target.value)}>
            {["Health", "Finance", "Business", "Personal", "Career", "Creative"].map(c => <option key={c}>{c}</option>)}
          </select>
        </Field>
        <Field t={t} label="Target date"><input type="date" style={monoInput(t)} value={date} onChange={(e) => setDate(e.target.value)} /></Field>
      </div>
      <Field t={t} label={`Progress · ${progress}%`}><input type="range" min="0" max="100" value={progress} onChange={(e) => setProgress(e.target.value)} style={{ width: "100%", accentColor: t.accent }} /></Field>
      <Field t={t} label="Notes"><textarea rows="3" style={inputStyle(t)} value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
    </Modal>
  );
};

// ─── Workout ─────────────────────────────────────────
const WorkoutModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [type, setType] = useState(initial?.type || "");
  const [duration, setDuration] = useState(initial?.duration || 60);
  const [date, setDate] = useState(initial?.date || window.OL_DATA.todayKey());
  const [notes, setNotes] = useState(initial?.notes || "");
  return (
    <Modal t={t} kicker={initial ? "EDIT · SESSION" : "LOG · NEW SESSION"} title={initial ? "Revise the session" : "Today's session"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => type && onSave({ type, duration: Number(duration), date, notes })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Session type"><input autoFocus style={inputStyle(t)} value={type} onChange={(e) => setType(e.target.value)} placeholder="Upper body — push, Threshold run…" /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Field t={t} label="Duration (min)"><input type="number" style={monoInput(t)} value={duration} onChange={(e) => setDuration(e.target.value)} /></Field>
        <Field t={t} label="Date"><input type="date" style={monoInput(t)} value={date} onChange={(e) => setDate(e.target.value)} /></Field>
      </div>
      <Field t={t} label="Notes"><textarea rows="3" style={inputStyle(t)} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Sets, reps, weights, how it felt…" /></Field>
    </Modal>
  );
};

// ─── Transaction ─────────────────────────────────────
const TransactionModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [desc, setDesc] = useState(initial?.desc || "");
  const [amount, setAmount] = useState(initial?.amount || 0);
  const [type, setType] = useState(initial?.type || "expense");
  const [category, setCategory] = useState(initial?.category || "Food");
  const [date, setDate] = useState(initial?.date || window.OL_DATA.todayKey());
  const cats = ["Salary", "Freelance", "Investment", "Housing", "Food", "Transport", "Entertainment", "Health", "Shopping", "Other"];
  return (
    <Modal t={t} kicker={initial ? "EDIT · ENTRY" : "RECORD · NEW ENTRY"} title={initial ? "Revise the ledger" : "A ledger entry"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => desc && onSave({ desc, amount: Number(amount), type, category, date })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Description"><input autoFocus style={inputStyle(t)} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Whole Foods, Salary, Rent…" /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
        <Field t={t} label="Amount"><input type="number" step="0.01" style={monoInput(t)} value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
        <Field t={t} label="Type">
          <select style={inputStyle(t)} value={type} onChange={(e) => setType(e.target.value)}>
            <option value="expense">Debit (DR)</option><option value="income">Credit (CR)</option>
          </select>
        </Field>
        <Field t={t} label="Date"><input type="date" style={monoInput(t)} value={date} onChange={(e) => setDate(e.target.value)} /></Field>
      </div>
      <Field t={t} label="Category">
        <select style={inputStyle(t)} value={category} onChange={(e) => setCategory(e.target.value)}>
          {cats.map(c => <option key={c}>{c}</option>)}
        </select>
      </Field>
    </Modal>
  );
};

// ─── Idea ────────────────────────────────────────────
const IdeaModal = ({ t, initial, onSave, onClose, onDelete }) => {
  const [title, setTitle] = useState(initial?.title || "");
  const [desc, setDesc] = useState(initial?.desc || "");
  const [status, setStatus] = useState(initial?.status || "idea");
  return (
    <Modal t={t} kicker={initial ? "EDIT · VENTURE" : "FILE · NEW IDEA"} title={initial ? "Revise the venture" : "An idea, captured"} onClose={onClose}
      footer={<>
        {initial && <Btn t={t} danger onClick={onDelete}>Delete</Btn>}
        <Btn t={t} onClick={onClose}>Cancel</Btn>
        <Btn t={t} primary onClick={() => title && onSave({ title, desc, status })}>Save</Btn>
      </>}
    >
      <Field t={t} label="Title"><input autoFocus style={inputStyle(t)} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What's the venture?" /></Field>
      <Field t={t} label="Description"><textarea rows="4" style={inputStyle(t)} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Why does this matter? Who's it for?" /></Field>
      <Field t={t} label="Status">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6 }}>
          {[["idea", "I · IDEA"], ["progress", "II · IN PROGRESS"], ["validated", "III · VALIDATED"]].map(([v, l]) => (
            <button key={v} type="button" onClick={() => setStatus(v)}
              style={{ padding: "8px 6px", background: status === v ? t.ink : t.paperAlt, color: status === v ? t.paper : t.ink, border: `1px solid ${status === v ? t.ink : t.ruleSoft}`, cursor: "pointer", fontFamily: '"JetBrains Mono", monospace', fontSize: 9, letterSpacing: "0.15em" }}>
              {l}
            </button>
          ))}
        </div>
      </Field>
    </Modal>
  );
};

window.OL_MODALS = { TaskModal, HabitModal, GoalModal, WorkoutModal, TransactionModal, IdeaModal };
